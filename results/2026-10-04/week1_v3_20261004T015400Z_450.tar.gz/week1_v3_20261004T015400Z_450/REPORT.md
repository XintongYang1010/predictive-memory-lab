# Week-one predictive memory diagnosis

Exploratory frozen-backbone AV2 results; inspect baseline reproduction before claims

Positive paired ES improvement means lower error than Keep. CIs resample complete scenarios.

|Policy|ES ↓|minADE6 ↓|minFDE6 ↓|Paired ES improvement [95% CI]|
|---|---:|---:|---:|---:|
|controller|1.5731|0.7090|1.3701|0.0000 [0.0000, 0.0000]|
|controller_base|1.5731|0.7090|1.3701|0.0000 [0.0000, 0.0000]|
|controller_temporal|1.5819|0.7178|1.3861|-0.0088 [-0.0178, 0.0002]|
|decay|1.5756|0.7075|1.3710|-0.0025 [-0.0073, 0.0026]|
|drop_worst|1.5745|0.7129|1.3821|-0.0014 [-0.0045, 0.0019]|
|keep|1.5731|0.7090|1.3701|0.0000 [0.0000, 0.0000]|
|keep_probe|1.5731|0.7090|1.3701|0.0000 [0.0000, 0.0000]|
|random_drop|1.5737|0.7087|1.3657|-0.0006 [-0.0028, 0.0015]|
|rebuild|1.6001|0.7159|1.3825|-0.0269 [-0.0391, -0.0148]|
|reset|1.6345|0.7376|1.3991|-0.0613 [-0.0831, -0.0377]|
|reset_all|2.0746|0.8694|1.7985|-0.5015 [-0.5867, -0.4183]|
|reweight|1.5740|0.7097|1.3660|-0.0009 [-0.0029, 0.0011]|
|threshold|1.5848|0.7135|1.3790|-0.0116 [-0.0231, -0.0005]|

All controller arms and keep_probe run two target-free influence probes per decision.
Keep is the native-cost baseline. Extra Rebuild forwards are included in the totals below.

|Policy|Seconds/scene|Forwards/scene|Probe forwards/scene|
|---|---:|---:|---:|
|controller|0.09104|7.00|4.00|
|controller_base|0.09098|7.00|4.00|
|controller_temporal|0.09150|7.02|4.00|
|decay|0.04039|3.00|0.00|
|drop_worst|0.04070|3.00|0.00|
|keep|0.04045|3.00|0.00|
|keep_probe|0.09045|7.00|4.00|
|random_drop|0.04068|3.00|0.00|
|rebuild|0.06010|5.00|0.00|
|reset|0.04043|3.00|0.00|
|reset_all|0.03676|3.00|0.00|
|reweight|0.04057|3.00|0.00|
|threshold|0.04036|3.00|0.00|

Feature ablations use identical Keep-generated Train/Dev branches and equal training/candidate budgets.
All arms are fixed on Dev before Eval; this table does not choose an Eval winner.

|Feature set|Dev selection|
|---|---|
|base|keep_fallback|
|temporal|gain_controller|
|temporal_influence|keep_fallback|
controller_temporal_over_controller_base: paired ES gain -0.00875258, CI [-0.01778339545428753, 0.00021933922544121716] (exploratory).
controller_over_controller_temporal: paired ES gain 0.00875258, CI [-0.0002193392254412174, 0.017783395454287528] (exploratory).

Controller selection: **keep_fallback** (development scenes only).
No shortlisted controller passed the development gate. Deployed controller uses Keep; this is not a learned improvement.

|Update|Keep|Reweight|Rebuild|Reset|
|---|---:|---:|---:|---:|
|40 frames|1000|0|0|0|
|50 frames|1000|0|0|0|

## Learning diagnostics

Tiny-set fit on Train only: **passed**.
The table describes recorded Dev single-edit branches. It does not measure complete deployed policies.
The logged controller below is the last training checkpoint, not necessarily the selected checkpoint.

|Predictor|Dev gain MSE ↓|Offline mean gain ↑|Intervention fraction|
|---|---:|---:|---:|
|zero_gain|0.0257978|0|0.000|
|train_mean_gain|0.0256136|0|0.000|
|stage_mean_gain|0.0255206|0|0.000|
|residual_ridge|0.0256096|-0.00158364|0.020|
|all_feature_ridge|0.0247759|0.00709986|0.273|
|last_logged_controller|0.0281385|-0.0021089|0.382|

Read `training_curves.png` and each `roundN.controller.diagnostics.json` alongside the rollout selection.
Tiny-set failure can reflect optimization or indistinguishable features with conflicting outcomes; it is not automatically an implementation bug.
A zero-weight layer has an undefined update/weight ratio (null). No universal ratio threshold is enforced.

![Controller learning diagnostics](training_curves.png)

Final metrics use the native 60-step forecast at step50. Curves compare the same absolute [50,100) target interval.
Group labels for policy curves are frozen at the reference model's step40 event.
Single-edit final-60-frame results are in summary.json / diagnostic_final; diagnostic retains legacy common-window gains. Rebuild at step40 is structurally a no-op.
b_minFDE6 selects the minimum-FDE mode then adds its Brier term; b_minFDE6_upstream minimizes the sum, matching the pinned repository.
No best-branch/oracle score is presented as deployed-controller performance.
