# SMOKE CHECK — NOT RESEARCH RESULTS

CPU/synthetic functional check; no research evidence

Positive paired ES improvement means lower error than Keep. CIs resample complete scenarios.

|Policy|ES ↓|minADE6 ↓|minFDE6 ↓|Paired ES improvement [95% CI]|
|---|---:|---:|---:|---:|
|controller|15.8292|13.8725|27.3355|0.0000 [0.0000, 0.0000]|
|decay|15.8328|13.8751|27.3331|-0.0036 [-0.0038, -0.0035]|
|drop_worst|15.8301|13.8713|27.3282|-0.0009 [-0.0014, -0.0001]|
|keep|15.8292|13.8725|27.3355|0.0000 [0.0000, 0.0000]|
|random_drop|15.8286|13.8735|27.3436|0.0006 [0.0003, 0.0009]|
|rebuild|15.8288|13.8721|27.3554|0.0004 [0.0001, 0.0007]|
|reset|15.8387|13.8850|27.3236|-0.0095 [-0.0102, -0.0090]|
|reset_all|15.8202|13.8733|27.2269|0.0090 [0.0066, 0.0113]|
|reweight|15.8290|13.8747|27.3079|0.0001 [-0.0002, 0.0004]|
|threshold|15.8292|13.8725|27.3355|0.0000 [0.0000, 0.0000]|

Controller selection: **keep_fallback** (development scenes only).
No shortlisted controller passed the development gate. Deployed controller uses Keep; this is not a learned improvement.

|Update|Keep|Reweight|Rebuild|Reset|
|---|---:|---:|---:|---:|
|40 frames|4|0|0|0|
|50 frames|4|0|0|0|

## Learning diagnostics

Tiny-set fit on Train only: **passed**.
The table describes recorded Dev single-edit branches. It does not measure complete deployed policies.
The logged controller below is the last training checkpoint, not necessarily the selected checkpoint.

|Predictor|Dev gain MSE ↓|Offline mean gain ↑|Intervention fraction|
|---|---:|---:|---:|
|zero_gain|2.02268e-05|0|0.000|
|train_mean_gain|1.26064e-05|0|0.000|
|stage_mean_gain|1.06124e-07|0|0.000|
|residual_ridge|1.26078e-05|0|0.000|
|all_feature_ridge|1.62536e-07|0|0.000|
|last_logged_controller|1.42944e-06|0|0.000|

Read `training_curves.png` and each `roundN.controller.diagnostics.json` alongside the rollout selection.
Tiny-set failure can reflect optimization or indistinguishable features with conflicting outcomes; it is not automatically an implementation bug.
A zero-weight layer has an undefined update/weight ratio (null). No universal ratio threshold is enforced.

![Controller learning diagnostics](training_curves.png)

Final metrics use the native 60-step forecast at step50. Curves compare the same absolute [50,100) target interval.
Group labels for policy curves are frozen at the reference model's step40 event.
Single-edit diagnostic results are in summary.json, split by event step. Rebuild at step40 is structurally a no-op.
b_minFDE6 selects the minimum-FDE mode then adds its Brier term; b_minFDE6_upstream minimizes the sum, matching the pinned repository.
No best-branch/oracle score is presented as deployed-controller performance.
