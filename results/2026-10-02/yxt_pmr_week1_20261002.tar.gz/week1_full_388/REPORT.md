# Week-one predictive memory diagnosis

Exploratory frozen-backbone AV2 results; inspect baseline reproduction before claims

Positive paired ES improvement means lower error than Keep. CIs resample complete scenarios.

|Policy|ES ↓|minADE6 ↓|minFDE6 ↓|Paired ES improvement [95% CI]|
|---|---:|---:|---:|---:|
|controller|1.5928|0.7288|1.4072|-0.0197 [-0.0345, -0.0045]|
|decay|1.5756|0.7075|1.3710|-0.0025 [-0.0073, 0.0026]|
|drop_worst|1.5745|0.7129|1.3821|-0.0014 [-0.0045, 0.0019]|
|keep|1.5731|0.7090|1.3701|0.0000 [0.0000, 0.0000]|
|random_drop|1.5737|0.7087|1.3657|-0.0006 [-0.0028, 0.0015]|
|rebuild|1.6001|0.7159|1.3825|-0.0269 [-0.0391, -0.0148]|
|reset|1.6345|0.7376|1.3991|-0.0613 [-0.0831, -0.0377]|
|reset_all|2.0746|0.8694|1.7985|-0.5015 [-0.5867, -0.4183]|
|reweight|1.5735|0.7094|1.3670|-0.0004 [-0.0022, 0.0013]|
|threshold|1.5848|0.7135|1.3790|-0.0116 [-0.0231, -0.0005]|

Final metrics use the native 60-step forecast at step50. Curves compare the same absolute [50,100) target interval.
Group labels for policy curves are frozen at the reference model's step40 event.
Single-edit diagnostic results are in summary.json, split by event step. Rebuild at step40 is structurally a no-op.
b_minFDE6 selects the minimum-FDE mode then adds its Brier term; b_minFDE6_upstream minimizes the sum, matching the pinned repository.
No best-branch/oracle score is presented as deployed-controller performance.
