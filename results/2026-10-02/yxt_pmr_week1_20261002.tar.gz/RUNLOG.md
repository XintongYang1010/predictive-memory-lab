# YXT PMR single GPU run — 2026-10-02 CST

## Inputs and environment

- Repository: `predictive-memory-lab`, commit `852f57d8d5a9aabcd9863c3150500760723aaa02`; pinned RealMotion commit `e292609f03ccd415c4f2ac6dd7fd907c098508e8`.
- ParaCloud: `gpu01`, `gpu_m`, one scheduler allocated A100 80 GB (physical GPU 0 for the default run).
- Remote project root: `/share/home/s2026316084/yxt_pmr_20261002`.
- Existing AV2 source: `/share/home/s2026316084/av2_map_encoders_20260923/raw_001/{train,val}.tar`; indexed source manifest SHA-256 `3bf4fdd9bf4b0bf14fe140cf872ee21ba28f197b76c03504ce7ff002493811a3`. Extracted only the scenes needed by the script defaults: 1,400 from train, split by scene hash into 1,000 train / 200 dev / 200 calibration, and 1,000 from val. The source archives were not modified.
- Official RealMotion checkpoint: `checkpoints/realmotion.pth`, SHA-256 `5f3c9f9cffecd094ee0fccce42a54d1797c77b2b3491393855f1846a71630f1c`, uploaded before server jobs and verified by read back.
- Image: `10.0.0.1:88/cadmin/pytorch@sha256:7b324d212a4450795b49edba9949b7cdc72429148a64e974334bfe5774d51385`, Python 3.11.14, PyTorch 2.9.1+cu128, CUDA runtime 12.8.
- Environment: repository `.venv` created by `scripts/setup.sh --av2` from the image Python with system site packages. Independent Conda cloning was attempted but the image lacks cached Conda packages and the server has no external network. All required wheels for this execution were downloaded locally, uploaded to `wheelhouse/`, and verified against `wheelhouse/manifest.json`. `PIP_NO_INDEX=1`, `PIP_FIND_LINKS=<wheelhouse>`, and `PIP_NO_DEPS=1` kept server installation offline and preserved the image's CUDA PyTorch. The image has no `libGL.so.1`, so the environment uses `opencv-python-headless==4.11.0.86` in place of the same version of graphical OpenCV. The host `git` executable was copied to the project `bin/` solely so the pinned checkout check in `pmr setup` could run inside the image. Some AV2 package dependencies unused by this execution were not installed; the tested AV2 imports and complete pipeline passed.

## Commands and jobs

The test and experiment commands ran inside the above image through Slurm managed `paracloud-socker` jobs. Standard output and error were saved in the corresponding `*_inside_<job>.log` files, with Slurm wrapper logs beside them.

| Job | GPUs | Command / role | Result |
|---|---:|---|---|
| 365, 372, 376 | 1 | CUDA and package preflight | Completed |
| 384 | 1 | Offline `bash scripts/setup.sh --av2`, headless OpenCV, runtime import check | Completed |
| 385 | 1 | `python -m pmr doctor --device cuda --strict`; `python -m pytest -q`; `python -m pmr smoke --device cuda --out /share/home/s2026316084/yxt_pmr_20261002/runs/gpu_smoke_385` | Completed; 23 tests passed |
| 386 | 1 | `CHECKPOINT=<uploaded checkpoint> PMR_PROCESSED_ROOT=<pilot cache> bash scripts/run_week1.sh <pilot raw> --train-scenes 100 --dev-scenes 30 --calib-scenes 30 --eval-scenes 100 --steps 100 --out <pilot output>` | Completed |
| 387 | 0 | Extract the default scene counts from the existing AV2 tar archives | Completed |
| 388 | 1 | `CHECKPOINT=<uploaded checkpoint> PMR_PROCESSED_ROOT=<default cache> bash scripts/run_week1.sh <default raw> --out <default output>` | Completed; default limits and 500 controller steps |

Exact absolute input and output paths, seed, code version, and GPU ID are in each run's `execution.json` and `settings.json`. Default output: `/share/home/s2026316084/yxt_pmr_20261002/runs/week1_full_388`; local copy: `week1_full_388/`. Pilot output: `/share/home/s2026316084/yxt_pmr_20261002/runs/av2_pilot_386`; local copy: `av2_pilot_386/`.

Several setup attempts before job 384 failed on ParaCloud command parsing, unwritable container home, missing offline Conda package cache, missing image `git`, and missing `libGL.so.1`. The Conda clone job 374 was cancelled when it attempted unavailable network downloads. These attempts did not produce experimental results. No source repository files or shared data were changed.

## Validation and result

- Default job 388: Slurm `COMPLETED`, exit 0; `run_stats.json` status `complete`; one GPU used and released. Runtime 2,238.4 s (37.3 min); 96,407 predictor forward calls; PyTorch peak allocated CUDA tensors 47.6 MiB. This allocation metric does not include the CUDA context or other users' GPU memory.
- `manifest.json`: 1,000 train / 200 dev / 200 calibration / 1,000 evaluation scenarios, with 2,400 unique IDs. `round0.controller.pt` exists; 500 training steps completed; 2,000 train, 400 dev, 2,000 diagnostic, and 10,000 policy evaluation JSONL records all have `status: ok`.
- The four checks in `correctness.json` are true: exact no-op replay, future blindness, branch isolation, and scene reset. Report, metrics CSV, summary JSON, and plot were generated and downloaded. `download_manifest.json` records local output sizes and SHA-256 hashes.
- On the 1,000 evaluation scenes, Keep energy score is 1.5731 and the learned controller is 1.5928. Paired energy score improvement over Keep is **-0.0197**, 95% bootstrap CI **[-0.0345, -0.0045]**; positive would mean lower error. The controller therefore underperformed Keep in this run. This is an exploratory frozen backbone AV2 result; the repository does not claim official RealMotion benchmark reproduction.

The cloned collaborator repository remains clean. All result directories are separate and no prior data or checkpoint was overwritten.
